"""TODO: Write a series of unittests for each resource using a test Delighted
         account.
"""
